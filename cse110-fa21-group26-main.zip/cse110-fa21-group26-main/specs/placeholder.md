Delete when file added to this folder
