<h1>Meeting Minutes</h1>

<h3>Topic: </h3>
Kickoff

<h3>Date:</h3> 
12:00 am

10 October 2021 


<h3>Atendance:</h3>

- Maryam 
- Kyle
- Anahi
- Arman
- Caitlin
- Harry
- Perry 


<h3>Agenda:</h3>

1. Get everyone on a GitHub repo
2. Plan when/where to meet
3. What group roles we want (we can assign them later so everyone has a fair chance of getting what they want)
4. Group contract
5. Discuss the project

<h3>Meeting Notes: </h3>

- Weekly Meetings (Date TBD using When2Meet)
- Meeting tuesday 10/12 after class

<h3>Action Items:</h3>

|Name| Task                        | Due Date |
|-----|----------------------------------------------|-------------------|
|Maryam| Contract: Contact info | 12 October 2021|
|Anahi| Contract: Primary Means of Communication and Expectations | 12 October 2021|
|Harry| Contract: Scheduling Meetings | 12 October 2021|
|Caitlin| General Responsibilities for All Team Members | 12 October 2021|
|Kyle| Contract: Conflict Resolution | 12 October 2021|

<h3>Meeting Recording: </h3>
<a href="https://drive.google.com/file/d/1z6dsCP6HykhBKZVBXuiZJ_D64yHkttwd/view?usp=sharing">Click here to view meeting recording</a>
