Delete when file added to folder
