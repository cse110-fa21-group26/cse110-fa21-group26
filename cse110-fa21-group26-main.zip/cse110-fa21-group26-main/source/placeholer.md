Delete when file created in this folder
